import React, { useState, useMemo, useCallback } from 'react';
import type { CaseReport, EvidenceItem, EvidenceTag } from '../types';
import { LEGAL_STATUTES } from '../constants';
import { Download, Printer, Copy, Check, AlertCircle } from './Icons';

interface ReportDisplayProps {
    report: CaseReport;
}

const getConfidenceClass = (confidence: EvidenceItem['confidence']) => {
    switch (confidence?.toLowerCase()) {
        case 'high': return 'bg-green-800 text-green-200';
        case 'medium': return 'bg-yellow-800 text-yellow-200';
        case 'low': return 'bg-gray-600 text-gray-300';
        default: return 'bg-gray-700 text-gray-400';
    }
};

const getTagClass = (tag: EvidenceItem['tag']) => {
    switch (tag) {
        case EvidenceTag.IMMIGRATION_INTENT: return 'bg-red-900 text-red-200';
        case EvidenceTag.FINANCIAL_TRANSACTION: return 'bg-yellow-900 text-yellow-200';
        case EvidenceTag.DECEPTION: return 'bg-purple-900 text-purple-200';
        case EvidenceTag.EMOTIONAL_MANIPULATION: return 'bg-pink-900 text-pink-200';
        case EvidenceTag.ID_DISCREPANCY: return 'bg-indigo-900 text-indigo-200';
        case EvidenceTag.LOVE_DENIAL: return 'bg-rose-900 text-rose-200';
        default: return 'bg-blue-900 text-blue-200';
    }
}

export const ReportDisplay: React.FC<ReportDisplayProps> = ({ report }) => {
    const [activeTag, setActiveTag] = useState<string | null>(null);
    const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

    const availableTags = useMemo(() => {
        const tags = new Set(