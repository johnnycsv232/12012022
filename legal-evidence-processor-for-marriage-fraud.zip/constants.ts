
export const LEGAL_STATUTES = {
    USC_1325_C: "8 USC §1325(c) – Marriage fraud to evade immigration law",
    MINN_518_02: "Minn. Stat. §518.02 – Fraud as grounds for annulment",
    USC_1546: "18 USC §1546 – Fraudulent use of IDs, documents, or visas",
};
